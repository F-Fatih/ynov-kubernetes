﻿ 

namespace Web.ViewModels.JobsViewModels
{
    public class JobApplicationViewModel
    {
       public User Applicant { get; set; }
       public Job Job { get; set; }
    }
}
