﻿ 

using System.Collections.Generic;

namespace Web.ViewModels.HomeViewModels
{
    public class IndexViewModel
    {
        public IEnumerable<Job> Jobs { get; set; }
    }
}
