﻿ 

namespace Web.Config
{
    public class ApiConfig 
    {
        public string IdentityApiUrl { get; set; }
        public string JobsApiUrl { get; set; }
    }
}
